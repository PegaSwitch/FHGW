#!/bin/bash

CURRENT_FOLDER=$(pwd)
KERNEL_VERSON=$(uname -r)
USBTOI2C_FILE="hid-cp2112.ko"
CURRENT_MODULES_LIBRARY_LOCATION="/lib/modules/${KERNEL_VERSON}/kernel/drivers/hid"

echo "========= PEGA Insert IDT Driver Start ======="

cd ${CURRENT_MODULES_LIBRARY_LOCATION} && insmod ${USBTOI2C_FILE}
echo 8a34001 0x5b > /sys/bus/i2c/devices/i2c-14/new_device

echo "========= PEGA Insert IDT Driver Done ======="
